var searchData=
[
  ['csr_5fwide',['CSR_WIDE',['../namespacehornet_1_1gpu_1_1batch__property.html#a9b934d17d6c148292718b8f4c2e0fb86',1,'hornet::gpu::batch_property']]]
];
