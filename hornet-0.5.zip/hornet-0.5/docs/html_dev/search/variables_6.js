var searchData=
[
  ['remove_5fbatch_5fduplicate',['REMOVE_BATCH_DUPLICATE',['../namespacehornet_1_1gpu_1_1batch__property.html#acb2013fb6bc95265b8b7350075df9957',1,'hornet::gpu::batch_property']]]
];
