var searchData=
[
  ['get_5fblockarray_5fptr',['get_blockarray_ptr',['../classhornet_1_1MemoryManager.html#adcf4fc1cf00f784b1de1e2c732998792',1,'hornet::MemoryManager']]]
];
