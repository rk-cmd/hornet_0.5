var searchData=
[
  ['block_5fsize_5fop2',['BLOCK_SIZE_OP2',['../namespacehornet__alg.html#a391c615488b7694f6bdaf7b09f15c9c9',1,'hornet_alg']]]
];
