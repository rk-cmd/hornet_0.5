var searchData=
[
  ['katz_2ecuh',['Katz.cuh',['../Dynamic_2KatzCentrality_2Katz_8cuh.html',1,'(Global Namespace)'],['../Static_2KatzCentrality_2Katz_8cuh.html',1,'(Global Namespace)']]]
];
