var searchData=
[
  ['min_5fedges_5fper_5fblock',['MIN_EDGES_PER_BLOCK',['../namespacehornet.html#a47b624918c309208236e92c74b594fdf',1,'hornet']]]
];
